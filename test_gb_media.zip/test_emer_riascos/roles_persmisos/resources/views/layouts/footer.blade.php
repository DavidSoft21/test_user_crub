<div class="footer-left " style="position: fixed;   bottom: 0px;">
    All rights reserved &copy; {{ date('Y') }}
</div>
