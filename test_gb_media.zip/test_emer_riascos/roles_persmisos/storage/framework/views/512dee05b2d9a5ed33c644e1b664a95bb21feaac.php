<li class="side-menus <?php echo e(Request::is('*') ? 'active' : ''); ?>">
    <a class="nav-link" href="/home">
        <i class=" fas fa-building"></i><span>Dashboard</span>
    </a>

    <?php if (! (!Auth::check())): ?>  
    

     <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
        <i class=" fas fa-users"></i><span>Users</span>
    </a>
 
 
   
    <a class="nav-link" href="<?php echo e(route('rol.index')); ?>">
        <i class=" fas fa-lock"></i><span>Roles</span>
    </a>
    

  
    <a class="nav-link" href="<?php echo e(route('blog.index')); ?>">
        <i class=" fas fa-blog"></i><span>Blogs</span>
    </a>

    <?php endif; ?>
    
   

</li>
<?php /**PATH C:\Users\Servidor de Soporte\Desktop\test_emer_riascos\roles_persmisos\resources\views/layouts/menu.blade.php ENDPATH**/ ?>