

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">News</h3>
        </div>
        <div class="section-body ">
            <div class="row d-flex justify-content-center">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="sm-col-12 md-col-4">
                    <div class="card m-1" style="width:350px; height:250px;">
                        <div class="card-header justify-content-center">
                            <h4 class="text-capitalize"> <?php echo e($blog->title); ?></h4>
                        </div>
                        <div class="card-body text-lowercase text-center">
                            <div class="overflow-auto" style="height:100px; overflow-y: scroll;">
                                <p>
                                    <?php echo e($blog->content); ?>

                                </p>
                            </div>
                        </div>
                        <div class="card-footer d-flex justify-content-between align-items-center">
                            <div class="card-text text-capitalize font-weight-bold">
                                <?php echo e($blog->name); ?>

                            </div>
                            <div class="actions text-lowercase">
                                <?php if(auth()->user() != null): ?>
                                    <?php if(auth()->user()->hasRole('admin')): ?>
                                        <?php echo Form::open(['route' => ['blog.destroy',$blog->id], 'method' => 'DELETE', 'style' =>'display:inline']); ?>

                                        <?php echo Form::submit('delete',['class'=> 'btn btn-danger']); ?> 
                                        <?php echo Form::close(); ?>  
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Servidor de Soporte\Desktop\test_emer_riascos\roles_persmisos\resources\views/home.blade.php ENDPATH**/ ?>