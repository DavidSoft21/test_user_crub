

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Create User</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <?php if($errors->any()): ?>
                            <div class="alert alert-dark alert-dismissible fade show aria-label=close">
                                <strong>Please check this fields!!</strong>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge badge-danger"><?php echo e($error); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <button type="button" class="close" data-dismiss='alert' aria-label="close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <?php endif; ?>
                            <?php echo Form::open(['route' => ['user.store'], 'method' => 'POST']); ?>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="name">Name:</label>
                                        <?php echo Form::text('name',null, ['class'=> 'form-control']); ?>


                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="edad">edad:</label>
                                        <?php echo Form::text('edad',null, ['class'=> 'form-control']); ?>


                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="sex">sex:</label>
                                        <?php echo Form::text('sex',null, ['class'=> 'form-control']); ?>


                                    </div>
                                </div>
                            </div>

                            


                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="email">Email:</label>
                                        <?php echo Form::email('email',null, ['class'=> 'form-control']); ?>


                                    </div>
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="password">´Password:</label>
                                        <?php echo Form::password('password', ['class'=> 'form-control']); ?>


                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="password-confirm">Password Confirm:</label>
                                        <?php echo Form::password('password-confirm', ['class'=> 'form-control']); ?>


                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="roles">Roles:</label>
                                        <?php echo Form::select('roles[]',$roles,[], ['class'=> 'form-control']); ?>


                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <?php echo Form::submit('Save', ['class' => 'btn btn-success btn-lg']); ?>

                                </div>
                            </div>

                           
                            <?php echo Form::close(); ?>  

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Servidor de Soporte\Desktop\test_emer_riascos\roles_persmisos\resources\views/users/create.blade.php ENDPATH**/ ?>