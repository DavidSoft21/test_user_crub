<div class="footer-left " style="position: fixed;   bottom: 0px;">
    All rights reserved &copy; <?php echo e(date('Y')); ?>

</div>
<?php /**PATH C:\Users\Servidor de Soporte\Desktop\test_emer_riascos\roles_persmisos\resources\views/layouts/footer.blade.php ENDPATH**/ ?>